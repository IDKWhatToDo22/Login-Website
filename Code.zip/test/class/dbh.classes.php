<?php

// $host = "localhost";
// $username = "id20299276_c33zr";
// $password = "P/L3{[Ew78icxses";
// $database = "id20299276_c3zr";

//Create a connection
$con = new mysqli('localhost','id20299276_c33zr','P/L3{[Ew78icxses','id20299276_c3zr');

//Check connection
if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

// echo "Connected successfully";

?>